﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace QRCodeApp
{
    public partial class LoginForm : Form
    {
        private readonly DatabaseHelper dbHelper = new DatabaseHelper();
        private TextBox txtUsername;
        private TextBox txtPassword;
        private Button btnLogin;
        private Button btnRegister;
        private Label lblUsername;
        private Label lblPassword;

        public LoginForm()
        {
            InitializeCustomComponents();
        }

        private void InitializeCustomComponents()
        {
            // Настройка формы
            this.Text = "Авторизация";
            this.ClientSize = new Size(350, 200);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            // Элементы управления
            lblUsername = new Label
            {
                Text = "Имя пользователя:",
                Location = new Point(20, 20),
                AutoSize = true
            };

            txtUsername = new TextBox
            {
                Location = new Point(20, 40),
                Size = new Size(290, 20)
            };

            lblPassword = new Label
            {
                Text = "Пароль:",
                Location = new Point(20, 70),
                AutoSize = true
            };

            txtPassword = new TextBox
            {
                Location = new Point(20, 90),
                Size = new Size(290, 20),
                PasswordChar = '*'
            };

            btnLogin = new Button
            {
                Text = "Войти",
                Location = new Point(20, 130),
                Size = new Size(140, 30)
            };
            btnLogin.Click += btnLogin_Click;

            btnRegister = new Button
            {
                Text = "Зарегистрироваться",
                Location = new Point(170, 130),
                Size = new Size(140, 30)
            };
            btnRegister.Click += btnRegister_Click;

            // Добавление элементов на форму
            this.Controls.Add(lblUsername);
            this.Controls.Add(txtUsername);
            this.Controls.Add(lblPassword);
            this.Controls.Add(txtPassword);
            this.Controls.Add(btnLogin);
            this.Controls.Add(btnRegister);
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text;

            if (string.IsNullOrEmpty(username))
            {
                MessageBox.Show("Введите имя пользователя", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var user = dbHelper.AuthenticateUser(username, password);
            if (user != null)
            {
                this.Hide();
                new MainForm(user).Show();
            }
            else
            {
                MessageBox.Show("Неверное имя пользователя или пароль", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text;

            if (string.IsNullOrEmpty(username))
            {
                MessageBox.Show("Введите имя пользователя", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (password.Length < 6)
            {
                MessageBox.Show("Пароль должен содержать минимум 6 символов", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int userId = dbHelper.RegisterUser(username, password);
            if (userId > 0)
            {
                MessageBox.Show("Регистрация успешна! Теперь вы можете войти.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (userId == -1)
            {
                MessageBox.Show("Пользователь с таким именем уже существует", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                MessageBox.Show("Ошибка при регистрации", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}