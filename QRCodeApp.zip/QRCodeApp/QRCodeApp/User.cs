﻿namespace QRCodeApp
{
    public class User
    {
        public int UserId { get; set; }
        public string Username { get; set; }
        public DateTime? LastLogin { get; set; }
    }
}