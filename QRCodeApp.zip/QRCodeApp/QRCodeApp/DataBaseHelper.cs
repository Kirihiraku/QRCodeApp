﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;

namespace QRCodeApp
{
    public class DatabaseHelper
    {
        private readonly string connectionString = "Server=localhost;Database=user62;Integrated Security=True;";

        public User AuthenticateUser(string username, string password)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (var transaction = connection.BeginTransaction())
                {
                    try
                    {
                        string authQuery = @"SELECT UserId, Username, LastLogin 
                                           FROM Users 
                                           WHERE Username = @Username 
                                           AND PasswordHash = @PasswordHash 
                                           AND IsActive = 1";

                        User authenticatedUser = null;

                        using (var authCommand = new SqlCommand(authQuery, connection, transaction))
                        {
                            authCommand.Parameters.AddWithValue("@Username", username);
                            authCommand.Parameters.AddWithValue("@PasswordHash", HashPassword(password));

                            using (var reader = authCommand.ExecuteReader())
                            {
                                if (reader.Read())
                                {
                                    authenticatedUser = new User
                                    {
                                        UserId = reader.GetInt32(0),
                                        Username = reader.GetString(1),
                                        LastLogin = reader.IsDBNull(2) ? (DateTime?)null : reader.GetDateTime(2)
                                    };
                                }
                            }
                        }

                        if (authenticatedUser == null)
                        {
                            transaction.Commit();
                            return null;
                        }

                        string updateQuery = "UPDATE Users SET LastLogin = GETDATE() WHERE UserId = @UserId";
                        using (var updateCommand = new SqlCommand(updateQuery, connection, transaction))
                        {
                            updateCommand.Parameters.AddWithValue("@UserId", authenticatedUser.UserId);
                            updateCommand.ExecuteNonQuery();
                        }

                        transaction.Commit();
                        return authenticatedUser;
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }
        }

        public int RegisterUser(string username, string password)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                string query = @"IF NOT EXISTS (SELECT 1 FROM Users WHERE Username = @Username)
                                BEGIN
                                    INSERT INTO Users (Username, PasswordHash, CreatedAt, IsActive) 
                                    OUTPUT INSERTED.UserId
                                    VALUES (@Username, @PasswordHash, GETDATE(), 1);
                                END
                                ELSE
                                BEGIN
                                    SELECT -1;
                                END";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@PasswordHash", HashPassword(password));

                    connection.Open();
                    return Convert.ToInt32(command.ExecuteScalar());
                }
            }
        }

        public int SaveQRCode(int userId, string qrText, int? size = null, string color = null, string notes = null)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                string query = @"INSERT INTO QRCodes (UserId, QRCodeText, Size, Color, Notes)
                                OUTPUT INSERTED.QRCodeId
                                VALUES (@UserId, @QRCodeText, @Size, @Color, @Notes)";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserId", userId);
                    command.Parameters.AddWithValue("@QRCodeText", qrText);
                    command.Parameters.AddWithValue("@Size", size.HasValue ? (object)size.Value : DBNull.Value);
                    command.Parameters.AddWithValue("@Color", !string.IsNullOrEmpty(color) ? (object)color : DBNull.Value);
                    command.Parameters.AddWithValue("@Notes", !string.IsNullOrEmpty(notes) ? (object)notes : DBNull.Value);

                    connection.Open();
                    return Convert.ToInt32(command.ExecuteScalar());
                }
            }
        }

        public bool UpdateQRCode(int qrCodeId, string notes)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                string query = @"UPDATE QRCodes 
                                SET Notes = @Notes
                                WHERE QRCodeId = @QRCodeId";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@QRCodeId", qrCodeId);
                    command.Parameters.AddWithValue("@Notes", !string.IsNullOrEmpty(notes) ? (object)notes : DBNull.Value);

                    connection.Open();
                    return command.ExecuteNonQuery() > 0;
                }
            }
        }

        public List<QRCodeHistory> GetUserQRHistory(int userId)
        {
            var history = new List<QRCodeHistory>();

            using (var connection = new SqlConnection(connectionString))
            {
                string query = @"SELECT QRCodeId, UserId, QRCodeText, CreatedAt, Size, Color, Notes
                                FROM QRCodes 
                                WHERE UserId = @UserId
                                ORDER BY CreatedAt DESC";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserId", userId);

                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            history.Add(new QRCodeHistory
                            {
                                QRCodeId = reader.GetInt32(0),
                                UserId = reader.GetInt32(1),
                                QRCodeText = reader.GetString(2),
                                CreatedAt = reader.GetDateTime(3),
                                Size = reader.IsDBNull(4) ? (int?)null : reader.GetInt32(4),
                                Color = reader.IsDBNull(5) ? null : reader.GetString(5),
                                Notes = reader.IsDBNull(6) ? null : reader.GetString(6)
                            });
                        }
                    }
                }
            }
            return history;
        }

        public bool DeleteQRCode(int qrCodeId)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM QRCodes WHERE QRCodeId = @QRCodeId";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@QRCodeId", qrCodeId);

                    connection.Open();
                    return command.ExecuteNonQuery() > 0;
                }
            }
        }

        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return BitConverter.ToString(hashedBytes).Replace("-", "").ToLower();
            }
        }
    }
}