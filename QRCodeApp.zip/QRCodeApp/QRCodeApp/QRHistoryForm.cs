﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Windows.Forms;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using MessagingToolkit.QRCode.Codec;

namespace QRCodeApp
{
    public partial class QRHistoryForm : Form
    {
        private readonly int userId;
        private readonly DatabaseHelper dbHelper = new DatabaseHelper();
        private List<QRCodeHistory> history;

        // Элементы управления
        private DataGridView dgvHistory;
        private PictureBox pbPreview;
        private GroupBox gbDetails;
        private Label lblDetails;
        private Panel pnlButtons;
        private Button btnView;
        private Button btnEditNote;
        private Button btnDelete;
        private Button btnSave;
        private Button btnClose;
        private TextBox txtSearch;
        private Button btnSearch;

        public QRHistoryForm(int userId)
        {
            this.userId = userId;
            InitializeCustomComponents();
            LoadQRHistory();
        }

        private void InitializeCustomComponents()
        {
            // Настройка основной формы
            this.Text = "История QR-кодов";
            this.ClientSize = new Size(1100, 800);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.BackColor = SystemColors.ControlLight;

            // Стиль для кнопок
            Font buttonFont = new Font("Arial", 10, FontStyle.Bold);
            Size buttonSize = new Size(180, 45);

            // Панель поиска
            Panel pnlSearch = new Panel
            {
                Location = new Point(20, 20),
                Size = new Size(1060, 50),
                BackColor = Color.WhiteSmoke,
                BorderStyle = BorderStyle.FixedSingle
            };

            txtSearch = new TextBox
            {
                Location = new Point(10, 10),
                Size = new Size(900, 30),
                Font = new Font("Arial", 10),
                PlaceholderText = "Поиск по содержимому или примечанию..."
            };

            btnSearch = new Button
            {
                Text = "Найти",
                Location = new Point(920, 10),
                Size = new Size(120, 30),
                Font = buttonFont,
                BackColor = Color.SteelBlue,
                ForeColor = Color.White
            };
            btnSearch.Click += BtnSearch_Click;

            pnlSearch.Controls.Add(txtSearch);
            pnlSearch.Controls.Add(btnSearch);

            // Таблица истории
            dgvHistory = new DataGridView
            {
                Location = new Point(20, 80),
                Size = new Size(1060, 400),
                BorderStyle = BorderStyle.Fixed3D,
                BackgroundColor = Color.White,
                RowHeadersVisible = false,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AllowUserToResizeRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                RowTemplate = { Height = 60 },
                Font = new Font("Arial", 9),
                GridColor = SystemColors.ControlDark
            };

            // Групповая панель для деталей
            gbDetails = new GroupBox
            {
                Text = "Детали QR-кода",
                Location = new Point(20, 490),
                Size = new Size(1060, 150),
                Font = new Font("Arial", 10, FontStyle.Bold),
                BackColor = Color.WhiteSmoke
            };

            lblDetails = new Label
            {
                Location = new Point(15, 25),
                Size = new Size(1030, 110),
                Font = new Font("Arial", 10),
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = Color.White,
                Padding = new Padding(10),
                TextAlign = ContentAlignment.TopLeft
            };
            gbDetails.Controls.Add(lblDetails);

            // Панель для кнопок
            pnlButtons = new Panel
            {
                Location = new Point(20, 650),
                Size = new Size(1060, 80),
                BackColor = Color.WhiteSmoke,
                BorderStyle = BorderStyle.FixedSingle
            };

            // Кнопки
            btnView = new Button
            {
                Text = "ПРОСМОТРЕТЬ",
                Size = buttonSize,
                Location = new Point(20, 15),
                Font = buttonFont,
                BackColor = Color.SteelBlue,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnView.FlatAppearance.BorderSize = 0;
            btnView.Click += BtnView_Click;

            btnEditNote = new Button
            {
                Text = "ИЗМЕНИТЬ ПРИМЕЧАНИЕ",
                Size = buttonSize,
                Location = new Point(220, 15),
                Font = buttonFont,
                BackColor = Color.Goldenrod,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnEditNote.FlatAppearance.BorderSize = 0;
            btnEditNote.Click += BtnEditNote_Click;

            btnDelete = new Button
            {
                Text = "УДАЛИТЬ",
                Size = buttonSize,
                Location = new Point(420, 15),
                Font = buttonFont,
                BackColor = Color.IndianRed,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnDelete.FlatAppearance.BorderSize = 0;
            btnDelete.Click += BtnDelete_Click;

            btnSave = new Button
            {
                Text = "СОХРАНИТЬ",
                Size = buttonSize,
                Location = new Point(620, 15),
                Font = buttonFont,
                BackColor = Color.SeaGreen,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnSave.FlatAppearance.BorderSize = 0;
            btnSave.Click += BtnSave_Click;

            btnClose = new Button
            {
                Text = "ЗАКРЫТЬ",
                Size = buttonSize,
                Location = new Point(820, 15),
                Font = buttonFont,
                BackColor = Color.Gray,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnClose.FlatAppearance.BorderSize = 0;
            btnClose.Click += (s, e) => this.Close();

            pnlButtons.Controls.Add(btnView);
            pnlButtons.Controls.Add(btnEditNote);
            pnlButtons.Controls.Add(btnDelete);
            pnlButtons.Controls.Add(btnSave);
            pnlButtons.Controls.Add(btnClose);

            // Добавление элементов на форму
            this.Controls.Add(pnlSearch);
            this.Controls.Add(dgvHistory);
            this.Controls.Add(gbDetails);
            this.Controls.Add(pnlButtons);
        }

        private void LoadQRHistory(string searchText = null)
        {
            history = dbHelper.GetUserQRHistory(userId);

            if (!string.IsNullOrWhiteSpace(searchText))
            {
                history = history.FindAll(q =>
                    q.QRCodeText.Contains(searchText, StringComparison.OrdinalIgnoreCase) ||
                    (q.Notes != null && q.Notes.Contains(searchText, StringComparison.OrdinalIgnoreCase)));
            }

            dgvHistory.Columns.Clear();

            // Настройка столбцов
            DataGridViewColumn[] columns = new DataGridViewColumn[]
            {
                new DataGridViewTextBoxColumn { Name = "QRCodeId", HeaderText = "ID", Width = 50 },
                new DataGridViewImageColumn { Name = "QRImage", HeaderText = "QR-код", ImageLayout = DataGridViewImageCellLayout.Zoom, Width = 100 },
                new DataGridViewTextBoxColumn { Name = "QRCodeText", HeaderText = "Содержимое", Width = 300 },
                new DataGridViewTextBoxColumn { Name = "CreatedAt", HeaderText = "Дата создания", Width = 150 },
                new DataGridViewTextBoxColumn { Name = "Size", HeaderText = "Размер", Width = 70 },
                new DataGridViewTextBoxColumn { Name = "Color", HeaderText = "Цвет", Width = 100 },
                new DataGridViewTextBoxColumn { Name = "Notes", HeaderText = "Примечание", AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill }
            };

            dgvHistory.Columns.AddRange(columns);

            // Заполнение данными
            foreach (var item in history)
            {
                Image qrThumbnail = GenerateQRThumbnail(item.QRCodeText, item.Color, item.Size ?? 10);
                dgvHistory.Rows.Add(
                    item.QRCodeId,
                    qrThumbnail,
                    item.QRCodeText.Length > 50 ? item.QRCodeText.Substring(0, 47) + "..." : item.QRCodeText,
                    item.CreatedAt.ToString("dd.MM.yyyy HH:mm"),
                    item.Size?.ToString() ?? "10",
                    item.Color ?? "Чёрный",
                    item.Notes ?? "Нет примечания"
                );
            }

            // Настройка внешнего вида
            dgvHistory.EnableHeadersVisualStyles = false;
            dgvHistory.ColumnHeadersDefaultCellStyle.BackColor = Color.SteelBlue;
            dgvHistory.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgvHistory.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Bold);
            dgvHistory.RowHeadersVisible = false;
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            if (dgvHistory.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите QR-код из списка", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int selectedIndex = dgvHistory.SelectedRows[0].Index;
            if (selectedIndex >= 0 && selectedIndex < history.Count)
            {
                SaveQRCodeToFile(history[selectedIndex]);
            }
        }

        private void SaveQRCodeToFile(QRCodeHistory qrItem)
        {
            SaveFileDialog saveDialog = new SaveFileDialog
            {
                Filter = "PNG Image|*.png|JPEG Image|*.jpg|Bitmap Image|*.bmp",
                Title = "Сохранить QR-код",
                FileName = $"QRCode_{qrItem.CreatedAt:yyyyMMdd_HHmmss}",
                RestoreDirectory = true
            };

            if (saveDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    // Генерируем QR-код с оригинальными параметрами
                    Color color = ParseColor(qrItem.Color);
                    int size = qrItem.Size ?? 10;

                    QRCodeEncoder encoder = new QRCodeEncoder
                    {
                        QRCodeForegroundColor = color,
                        QRCodeBackgroundColor = Color.White,
                        QRCodeScale = size
                    };

                    using (Bitmap qrCode = encoder.Encode(qrItem.QRCodeText))
                    {
                        // Определяем формат по расширению файла
                        ImageFormat format = ImageFormat.Png;
                        string extension = Path.GetExtension(saveDialog.FileName).ToLower();

                        if (extension == ".jpg" || extension == ".jpeg")
                        {
                            format = ImageFormat.Jpeg;
                        }
                        else if (extension == ".bmp")
                        {
                            format = ImageFormat.Bmp;
                        }

                        // Сохраняем изображение
                        qrCode.Save(saveDialog.FileName, format);

                        MessageBox.Show($"QR-код успешно сохранен как {extension.ToUpper()} файл",
                            "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при сохранении: {ex.Message}",
                        "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void BtnView_Click(object sender, EventArgs e)
        {
            if (dgvHistory.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите QR-код из списка", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int selectedIndex = dgvHistory.SelectedRows[0].Index;
            if (selectedIndex >= 0 && selectedIndex < history.Count)
            {
                var item = history[selectedIndex];

                lblDetails.Text = $"Дата создания: {item.CreatedAt:dd.MM.yyyy HH:mm}\n" +
                                $"Размер: {item.Size ?? 10}\n" +
                                $"Цвет: {item.Color ?? "Чёрный"}\n" +
                                $"Примечание: {item.Notes ?? "нет"}\n" +
                                $"Содержимое: {item.QRCodeText}";
            }
        }

        private void BtnEditNote_Click(object sender, EventArgs e)
        {
            if (dgvHistory.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите QR-код из списка", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int selectedIndex = dgvHistory.SelectedRows[0].Index;
            if (selectedIndex >= 0 && selectedIndex < history.Count)
            {
                var item = history[selectedIndex];

                using (var editForm = new Form())
                {
                    editForm.Text = "Редактирование примечания";
                    editForm.Size = new Size(500, 300);
                    editForm.StartPosition = FormStartPosition.CenterParent;
                    editForm.FormBorderStyle = FormBorderStyle.FixedDialog;

                    TextBox txtEditNote = new TextBox
                    {
                        Multiline = true,
                        Dock = DockStyle.Fill,
                        Text = item.Notes ?? "",
                        ScrollBars = ScrollBars.Vertical,
                        Font = new Font("Arial", 10),
                        AcceptsReturn = true,
                        AcceptsTab = true
                    };

                    Button btnSaveNote = new Button
                    {
                        Text = "СОХРАНИТЬ",
                        Dock = DockStyle.Bottom,
                        Height = 45,
                        Font = new Font("Arial", 10, FontStyle.Bold),
                        BackColor = Color.SteelBlue,
                        ForeColor = Color.White,
                        FlatStyle = FlatStyle.Flat
                    };
                    btnSaveNote.FlatAppearance.BorderSize = 0;
                    btnSaveNote.Click += (s, args) =>
                    {
                        dbHelper.UpdateQRCode(item.QRCodeId, txtEditNote.Text);
                        editForm.DialogResult = DialogResult.OK;
                        editForm.Close();
                    };

                    editForm.Controls.Add(txtEditNote);
                    editForm.Controls.Add(btnSaveNote);

                    if (editForm.ShowDialog() == DialogResult.OK)
                    {
                        LoadQRHistory(txtSearch.Text);
                    }
                }
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (dgvHistory.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите QR-код для удаления", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int selectedIndex = dgvHistory.SelectedRows[0].Index;
            if (selectedIndex >= 0 && selectedIndex < history.Count)
            {
                var item = history[selectedIndex];
                if (MessageBox.Show($"Вы уверены, что хотите удалить QR-код от {item.CreatedAt:dd.MM.yyyy}?",
                    "Подтверждение удаления", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    if (dbHelper.DeleteQRCode(item.QRCodeId))
                    {
                        history.RemoveAt(selectedIndex);
                        dgvHistory.Rows.RemoveAt(selectedIndex);
                        lblDetails.Text = "Выберите QR-код из списка для просмотра";
                    }
                    else
                    {
                        MessageBox.Show("Не удалось удалить QR-код", "Ошибка",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void BtnSearch_Click(object sender, EventArgs e)
        {
            LoadQRHistory(txtSearch.Text.Trim());
        }

        private Image GenerateQRThumbnail(string text, string colorValue, int size)
        {
            try
            {
                Color color = ParseColor(colorValue);
                QRCodeEncoder encoder = new QRCodeEncoder
                {
                    QRCodeForegroundColor = color,
                    QRCodeBackgroundColor = Color.White,
                    QRCodeScale = Math.Max(1, size / 3)
                };

                using (Bitmap qrCode = encoder.Encode(text))
                {
                    return ResizeImage(qrCode, 80, 80);
                }
            }
            catch
            {
                Bitmap emptyImage = new Bitmap(80, 80);
                using (Graphics g = Graphics.FromImage(emptyImage))
                {
                    g.Clear(Color.White);
                    g.DrawString("Ошибка", new Font("Arial", 8), Brushes.Red, 10, 30);
                }
                return emptyImage;
            }
        }

        private Image ResizeImage(Image image, int width, int height)
        {
            Bitmap result = new Bitmap(width, height);
            using (Graphics g = Graphics.FromImage(result))
            {
                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                g.DrawImage(image, 0, 0, width, height);
            }
            return result;
        }

        private Color ParseColor(string colorValue)
        {
            if (string.IsNullOrEmpty(colorValue))
                return Color.Black;

            try
            {
                if (Color.FromName(colorValue).IsKnownColor)
                    return Color.FromName(colorValue);

                if (Regex.IsMatch(colorValue, "^#?([0-9a-fA-F]{8}|[0-9a-fA-F]{6}|[0-9a-fA-F]{4}|[0-9a-fA-F]{3})$"))
                {
                    colorValue = colorValue.Replace("#", "");

                    switch (colorValue.Length)
                    {
                        case 8:
                            return Color.FromArgb(
                            Convert.ToInt32(colorValue.Substring(0, 2), 16),
                            Convert.ToInt32(colorValue.Substring(2, 2), 16),
                            Convert.ToInt32(colorValue.Substring(4, 2), 16),
                            Convert.ToInt32(colorValue.Substring(6, 2), 16));
                        case 6:
                            return Color.FromArgb(
                            Convert.ToInt32(colorValue.Substring(0, 2), 16),
                            Convert.ToInt32(colorValue.Substring(2, 2), 16),
                            Convert.ToInt32(colorValue.Substring(4, 2), 16));
                        case 3:
                            return Color.FromArgb(
                            Convert.ToInt32(new string(colorValue[0], 2), 16),
                            Convert.ToInt32(new string(colorValue[1], 2), 16),
                            Convert.ToInt32(new string(colorValue[2], 2), 16));
                    }
                }

                if (Regex.IsMatch(colorValue, @"^(\d{1,3},){2}\d{1,3}(,\d{1,3})?$"))
                {
                    var parts = colorValue.Split(',');
                    if (parts.Length == 3) return Color.FromArgb(
                        int.Parse(parts[0]), int.Parse(parts[1]), int.Parse(parts[2]));
                    if (parts.Length == 4) return Color.FromArgb(
                        int.Parse(parts[0]), int.Parse(parts[1]), int.Parse(parts[2]), int.Parse(parts[3]));
                }
            }
            catch { }

            return Color.Black;
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            if (pbPreview?.Image != null)
                pbPreview.Image.Dispose();
        }
    }
}