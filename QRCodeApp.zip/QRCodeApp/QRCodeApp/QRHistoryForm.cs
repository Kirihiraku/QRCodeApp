﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;
using MessagingToolkit.QRCode.Codec;
using System.Text.RegularExpressions;
using System.Globalization;

namespace QRCodeApp
{
    public partial class QRHistoryForm : Form
    {
        private readonly int userId;
        private readonly DatabaseHelper dbHelper = new DatabaseHelper();
        private List<QRCodeHistory> history;

        // Элементы управления
        private DataGridView dataGridView1;
        private Button btnClose;
        private Button btnViewQR;
        private Button btnDelete;
        private PictureBox pictureBox1;
        private Label lblDetails;

        public QRHistoryForm(int userId)
        {
            this.userId = userId;
            InitializeCustomComponents();
            LoadQRHistory();
        }

        private void InitializeCustomComponents()
        {
            // Настройка формы
            this.Text = "История QR-кодов";
            this.ClientSize = new Size(1000, 600);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            // DataGridView
            dataGridView1 = new DataGridView
            {
                Location = new Point(20, 20),
                Size = new Size(960, 300),
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
                ReadOnly = true,
                AllowUserToAddRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                RowTemplate = { Height = 80 }
            };

            // PictureBox
            pictureBox1 = new PictureBox
            {
                Location = new Point(20, 330),
                Size = new Size(300, 200),
                BorderStyle = BorderStyle.FixedSingle,
                SizeMode = PictureBoxSizeMode.Zoom
            };

            // Label для деталей
            lblDetails = new Label
            {
                Location = new Point(330, 330),
                Size = new Size(300, 100),
                Text = "Выберите QR-код из списка для просмотра",
                Font = new Font("Arial", 10)
            };

            // Кнопки
            btnViewQR = new Button
            {
                Text = "Просмотреть QR-код",
                Location = new Point(330, 450),
                Size = new Size(150, 30)
            };
            btnViewQR.Click += BtnViewQR_Click;

            btnDelete = new Button
            {
                Text = "Удалить",
                Location = new Point(500, 450),
                Size = new Size(150, 30),
                BackColor = Color.LightCoral
            };
            btnDelete.Click += BtnDelete_Click;

            btnClose = new Button
            {
                Text = "Закрыть",
                Location = new Point(830, 550),
                Size = new Size(150, 30)
            };
            btnClose.Click += (s, e) => this.Close();

            // Добавление элементов
            this.Controls.Add(dataGridView1);
            this.Controls.Add(pictureBox1);
            this.Controls.Add(lblDetails);
            this.Controls.Add(btnViewQR);
            this.Controls.Add(btnDelete);
            this.Controls.Add(btnClose);
        }

        private void LoadQRHistory()
        {
            history = dbHelper.GetUserQRHistory(userId);
            dataGridView1.Columns.Clear();

            // Колонки
            dataGridView1.Columns.Add("QRCodeId", "ID");
            dataGridView1.Columns["QRCodeId"].Width = 50;

            var qrImageColumn = new DataGridViewImageColumn
            {
                HeaderText = "QR-код",
                Name = "QRImage",
                ImageLayout = DataGridViewImageCellLayout.Zoom
            };
            dataGridView1.Columns.Add(qrImageColumn);
            dataGridView1.Columns["QRImage"].Width = 100;

            dataGridView1.Columns.Add("QRCodeText", "Текст");
            dataGridView1.Columns["QRCodeText"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

            dataGridView1.Columns.Add("CreatedAt", "Дата создания");
            dataGridView1.Columns["CreatedAt"].Width = 120;

            dataGridView1.Columns.Add("Size", "Размер");
            dataGridView1.Columns["Size"].Width = 60;

            dataGridView1.Columns.Add("ColorText", "Цвет");
            dataGridView1.Columns["ColorText"].Width = 80;

            var colorColumn = new DataGridViewImageColumn
            {
                HeaderText = "Цвет",
                Name = "Color",
                ImageLayout = DataGridViewImageCellLayout.Zoom
            };
            dataGridView1.Columns.Add(colorColumn);
            dataGridView1.Columns["Color"].Width = 60;

            // Заполнение данных
            foreach (var item in history)
            {
                Color color = ParseColor(item.Color);
                Image qrThumbnail = GenerateQRThumbnail(item.QRCodeText, color, item.Size ?? 10);
                Image colorImage = CreateColorImage(color);

                dataGridView1.Rows.Add(
                    item.QRCodeId,
                    qrThumbnail,
                    item.QRCodeText.Length > 50 ? item.QRCodeText.Substring(0, 47) + "..." : item.QRCodeText,
                    item.CreatedAt.ToString("g"),
                    item.Size?.ToString() ?? "По умолчанию",
                    item.Color ?? "Чёрный",
                    colorImage
                );
            }
        }

        private Color ParseColor(string colorValue)
        {
            if (string.IsNullOrEmpty(colorValue))
                return Color.Black;

            try
            {
                // 1. Попробовать как имя цвета (red, green и т.д.)
                if (Color.FromName(colorValue).IsKnownColor)
                    return Color.FromName(colorValue);

                // 2. Попробовать HEX (#AARRGGBB, #RRGGBB, #ARGB, #RGB)
                if (Regex.IsMatch(colorValue, "^#?([0-9a-fA-F]{8}|[0-9a-fA-F]{6}|[0-9a-fA-F]{4}|[0-9a-fA-F]{3})$"))
                {
                    colorValue = colorValue.Replace("#", "");

                    // Обработка разных HEX форматов
                    switch (colorValue.Length)
                    {
                        case 8: // AARRGGBB
                            return Color.FromArgb(
                                int.Parse(colorValue.Substring(0, 2), NumberStyles.HexNumber),
                                int.Parse(colorValue.Substring(2, 2), NumberStyles.HexNumber),
                                int.Parse(colorValue.Substring(4, 2), NumberStyles.HexNumber),
                                int.Parse(colorValue.Substring(6, 2), NumberStyles.HexNumber));

                        case 6: // RRGGBB
                            return Color.FromArgb(
                                255,
                                int.Parse(colorValue.Substring(0, 2), NumberStyles.HexNumber),
                                int.Parse(colorValue.Substring(2, 2), NumberStyles.HexNumber),
                                int.Parse(colorValue.Substring(4, 2), NumberStyles.HexNumber));

                        case 4: // ARGB
                            return Color.FromArgb(
                                int.Parse(new string(colorValue[0], 2), NumberStyles.HexNumber),
                                int.Parse(new string(colorValue[1], 2), NumberStyles.HexNumber),
                                int.Parse(new string(colorValue[2], 2), NumberStyles.HexNumber),
                                int.Parse(new string(colorValue[3], 2), NumberStyles.HexNumber));

                        case 3: // RGB
                            return Color.FromArgb(
                                255,
                                int.Parse(new string(colorValue[0], 2), NumberStyles.HexNumber),
                                int.Parse(new string(colorValue[1], 2), NumberStyles.HexNumber),
                                int.Parse(new string(colorValue[2], 2), NumberStyles.HexNumber));
                    }
                }

                // 3. Попробовать RGB или ARGB в десятичном формате (255,0,0 или 255,255,0,0)
                if (Regex.IsMatch(colorValue, @"^(\d{1,3},){2}\d{1,3}(,\d{1,3})?$"))
                {
                    var parts = colorValue.Split(',');
                    if (parts.Length == 3) // RGB
                        return Color.FromArgb(
                            int.Parse(parts[0]),
                            int.Parse(parts[1]),
                            int.Parse(parts[2]));

                    if (parts.Length == 4) // ARGB
                        return Color.FromArgb(
                            int.Parse(parts[0]),
                            int.Parse(parts[1]),
                            int.Parse(parts[2]),
                            int.Parse(parts[3]));
                }

                // 4. Попробовать как целое число (например, -65536)
                if (int.TryParse(colorValue, out int argb))
                    return Color.FromArgb(argb);
            }
            catch { }

            return Color.Black;
        }

        private Image GenerateQRThumbnail(string text, Color color, int size)
        {
            try
            {
                QRCodeEncoder encoder = new QRCodeEncoder
                {
                    QRCodeForegroundColor = color,
                    QRCodeBackgroundColor = Color.White,
                    QRCodeScale = Math.Max(1, size / 3)
                };

                using (Bitmap qrCode = encoder.Encode(text))
                {
                    return ResizeImage(qrCode, 80, 80);
                }
            }
            catch
            {
                Bitmap emptyImage = new Bitmap(80, 80);
                using (Graphics g = Graphics.FromImage(emptyImage))
                {
                    g.Clear(Color.White);
                    g.DrawString("Ошибка", new Font("Arial", 8), Brushes.Red, 10, 30);
                }
                return emptyImage;
            }
        }

        private Image ResizeImage(Image image, int width, int height)
        {
            Bitmap result = new Bitmap(width, height);
            using (Graphics g = Graphics.FromImage(result))
            {
                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                g.DrawImage(image, 0, 0, width, height);
            }
            return result;
        }

        private Image CreateColorImage(Color color)
        {
            Bitmap bmp = new Bitmap(20, 20);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.Clear(color);
                g.DrawRectangle(Pens.Black, 0, 0, 19, 19);
            }
            return bmp;
        }

        private void BtnViewQR_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите QR-код из списка", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int selectedIndex = dataGridView1.SelectedRows[0].Index;
            if (selectedIndex >= 0 && selectedIndex < history.Count)
            {
                var item = history[selectedIndex];
                Color color = ParseColor(item.Color);
                int size = item.Size ?? 10;

                try
                {
                    QRCodeEncoder encoder = new QRCodeEncoder
                    {
                        QRCodeForegroundColor = color,
                        QRCodeBackgroundColor = Color.White,
                        QRCodeScale = size
                    };

                    Bitmap qrCode = encoder.Encode(item.QRCodeText);
                    pictureBox1.Image = qrCode;

                    lblDetails.Text = $"Дата создания: {item.CreatedAt:g}\n" +
                                    $"Размер: {size}\n" +
                                    $"Цвет: {item.Color ?? "Чёрный"}\n" +
                                    $"Текст: {item.QRCodeText}";
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при генерации QR-кода: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите QR-код для удаления", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int selectedIndex = dataGridView1.SelectedRows[0].Index;
            if (selectedIndex >= 0 && selectedIndex < history.Count)
            {
                var item = history[selectedIndex];
                if (MessageBox.Show("Вы уверены, что хотите удалить этот QR-код?", "Подтверждение",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    if (dbHelper.DeleteQRCode(item.QRCodeId))
                    {
                        history.RemoveAt(selectedIndex);
                        dataGridView1.Rows.RemoveAt(selectedIndex);
                        pictureBox1.Image = null;
                        lblDetails.Text = "QR-код успешно удален";
                    }
                    else
                    {
                        MessageBox.Show("Не удалось удалить QR-код", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
    }
}