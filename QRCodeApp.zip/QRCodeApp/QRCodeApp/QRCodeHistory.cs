﻿using System;

namespace QRCodeApp
{
    public class QRCodeHistory
    {
        public int QRCodeId { get; set; }
        public int UserId { get; set; }
        public string QRCodeText { get; set; }
        public DateTime CreatedAt { get; set; }
        public int? Size { get; set; }
        public string Color { get; set; }
    }
}